<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand nav-link disabled" href="#">Razi</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Select Page
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <a href="checkpoint-index.php" class="dropdown-item">Checkpoint</a> 
	                                                                                                                                                                                                     
        	<a class="dropdown-item" href="history_patroli-index.php">History</a>
		<a class="dropdown-item" href="rute-index.php">Rute</a>
		<a class="dropdown-item" href="user-index.php">User</a>
		<a class="dropdown-item" href="zona-index.php">Zona</a>
	<!-- TABLE_BUTTONS -->
        </div>
      </li>
    </ul>
  </div>
</nav>